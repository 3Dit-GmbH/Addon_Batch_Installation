# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name": "STEP OCC import",
    "author": "ambi",
    "description": "STEP OpenCASCADE import",
    "blender": (2, 80, 0),
    "version": (1, 0, 0),
    "location": "",
    # "warning": "Alpha",
    "category": "Import",
}

global_file_cache = {}

import bpy
import numpy as np
import bmesh
import mathutils as mu
import ntpath

# import math

from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty

# from collections import defaultdict

from .bpy_amb import bbmesh
from .bpy_amb import utils
from .sizeof import total_size

# utils.memorytrace_start()


def tri_ori(p1, p2, p3):
    # skip colinearity test
    return (p2[1] - p1[1]) * (p3[0] - p2[0]) - (p2[0] - p1[0]) * (p3[1] - p2[1]) > 0


def exclusive_collection_link(obj, col):
    old_col = obj.users_collection

    # Move the object to its own collection
    col.objects.link(obj)

    # bugfix: not in master collection bug
    # master_collection.objects.unlink(obj)
    if len(old_col) > 0:
        for c in old_col:
            c.objects.unlink(obj)


def context_free_merge(obj, merge_distance):
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bmesh.ops.remove_doubles(bm, verts=bm.verts[:], dist=merge_distance)
    bm.to_mesh(obj.data)
    bm.free()


def rotate_selection_on_axis(angle, axis):
    """ Angle in radians, axis is X, Y or Z """
    assert axis in {"X", "Y", "Z"}
    constraint = (axis == "X", axis == "Y", axis == "Z")
    bpy.ops.transform.rotate(
        value=angle,
        orient_axis=axis,
        orient_type="GLOBAL",
        orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)),
        orient_matrix_type="GLOBAL",
        constraint_axis=constraint,
        mirror=True,
        use_proportional_edit=False,
        proportional_edit_falloff="SMOOTH",
        proportional_size=1,
        use_proportional_connected=False,
        use_proportional_projected=False,
    )


def scale_selection_on_axis(amount, axis):
    """ Axis is X, Y or Z """
    axii = {"X": 0, "Y": 1, "Z": 2}
    assert axis in axii
    constraint = [False, False, False]
    constraint[axii[axis]] = True
    scaling = [1, 1, 1]
    scaling[axii[axis]] = amount
    print(scaling, constraint)
    bpy.ops.transform.resize(
        value=scaling,
        orient_type="GLOBAL",
        orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)),
        orient_matrix_type="GLOBAL",
        constraint_axis=constraint,
        mirror=True,
        use_proportional_edit=False,
        proportional_edit_falloff="SMOOTH",
        proportional_size=1,
        use_proportional_connected=False,
        use_proportional_projected=False,
    )


def build_mesh(
    objdata,
    shp,
    lind,
    angd,
    color,
    only_bbox=False,
    color_choice=True,
    norms_choice=True,
    vcol_name="Colors",
    verbose=False,
):
    bm = bmesh.new()

    # bm.from_mesh(objdata)
    # bmesh.ops.delete(bm, geom=bm.verts[:], context="VERTS")

    # print("----enter bm")

    from . import importer

    if only_bbox:
        mtx, _ = importer.build_bm(shp, bm, style="BOUNDING_BOX")
    else:
        mtx, norms = importer.build_bm(shp, bm, style="TRIANGLES", lin_def=lind, ang_def=angd)
        # print("----built bm")

        rgb = (color.Red(), color.Green(), color.Blue(), 1.0)

        # mark all non-manifold edges as sharp
        for e in bm.edges:
            if not e.is_manifold:
                e.seam = True
                e.smooth = False

        # set colors
        if color_choice and color is not None:
            color_layer = bm.loops.layers.color.get(vcol_name)
            if color_layer is None:
                color_layer = bm.loops.layers.color.new(vcol_name)

            for face in bm.faces:
                for loop in face.loops:
                    loop[color_layer] = rgb

        if verbose:
            print("Polys: {}, Verts: {}".format(len(bm.faces), len(bm.verts)))

    # update mesh from Bmesh
    bm.to_mesh(objdata)

    if not only_bbox and norms is not None:
        # TODO: No way to set custom normals through Bmesh? Come on
        if norms_choice:
            objdata.normals_split_custom_set(np.array(norms))

    return mtx


class PG_Stepper(bpy.types.PropertyGroup):

    fw_as: bpy.props.EnumProperty(
        items=[
            ("XPOS", "X", "", 0),
            # ("XNEG", "X-", "", 1),
            ("YPOS", "Y", "", 2),
            # ("YNEG", "Y-", "", 3),
            ("ZPOS", "Z", "", 4),
            # ("ZNEG", "Z-", "", 5),
        ],
        name="Forward",
        default="ZPOS",
        description="Forward axis of the imported model",
    )

    up_as: bpy.props.EnumProperty(
        items=[
            ("XPOS", "X", "", 0),
            # ("XNEG", "X-", "", 1),
            ("YPOS", "Y", "", 2),
            # ("YNEG", "Y-", "", 3),
            ("ZPOS", "Z", "", 4),
            # ("ZNEG", "Z-", "", 5),
        ],
        name="Up",
        default="YPOS",
        description="Up axis of the imported model",
    )

    scale: bpy.props.FloatProperty(
        name="Scale", description="Set object scale", default=0.01, min=0.0001
    )

    merge_distance: bpy.props.FloatProperty(
        name="Merge distance",
        description="Distance on which vertices are merged.\n"
        "0.0 = No merging\n"
        "May cause shading issues if enabled",
        default=0.0,
        min=0.0,
    )

    # min_sharp: bpy.props.FloatProperty(
    #     name="Sharp angle",
    #     description="Minimum angle on which an edge can be marked as sharp",
    #     default=0.0,
    #     min=0.0,
    #     max=180.0,
    # )

    lin_deflection: bpy.props.FloatProperty(
        name="Linear deflection",
        description="Smaller values increase polygon count. Higher values lower polygon count.",
        default=0.8,
        min=0.002,
        max=2.0,
    )

    ang_deflection: bpy.props.FloatProperty(
        name="Angular deflection",
        description="Smaller values increase polygon count. Higher values lower polygon count.",
        default=0.5,
        min=0.002,
        max=2.0,
    )

    color_choice: bpy.props.BoolProperty(name="Colors", description="Import colors", default=True)

    norms_choice: bpy.props.BoolProperty(
        name="Normals", description="Import custom normals", default=True
    )

    # rotate_ZY: bpy.props.BoolProperty(
    #     name="Rotate Y-up to Z-up",
    #     description="Rotate from Y-up to Z-up (Z-up is Blender default)",
    #     default=True,
    # )

    # default: Y forward, Z up

    ignore_empty: bpy.props.BoolProperty(
        name="Ignore empty",
        description="Skip shapes with empty descriptions",
        default=True,
        options={"HIDDEN"},
    )

    only_bbox: bpy.props.BoolProperty(
        name="Only bounding box",
        description="Load only shape bounding boxes",
        default=False,
        options={"HIDDEN"},
    )

    linked_copies: bpy.props.BoolProperty(
        name="Duplicate name as linked copy",
        description="Create linked copies from shapes with matching labels",
        default=True,
        options={"HIDDEN"},
    )

    interactive: bpy.props.BoolProperty(
        name="Interactive",
        description="Show interactive build and collapse inner collections",
        default=False,
        options={"HIDDEN"},
    )

    # fold_collections: bpy.props.BoolProperty(
    #     name="Fold collections",
    #     description="Collapse collections in the outliner",
    #     default=True,
    # )


def draw_interface(self, context, prg, limited=False):
    # print(prg.__annotations__.keys())

    layout = self.layout

    def spacer(inpl):
        row = inpl.row()
        row.ui_units_y = 0.5
        row.label(text="")
        return row

    row = layout.row()
    if limited:
        pass
        # row.label(text="NOTE: Can't go lower res once higher res")
    else:
        row.label(text="STEPper import options:")

    if not limited:
        col = layout.box()
    else:
        col = layout
    col = col.column(align=True)

    # # pixel
    # row = col.row()
    # row.label(text="Pixels", icon="NODE_TEXTURE")

    # spacer(col)

    # row = col.row(align=True)
    # row.label(text="Channel")
    # row.prop(prg, "channel", text="")

    # if prg.channel != "A":
    #     row = col.row(align=True)
    #     row.label(text="Background")
    #     row.prop(prg, "back_color", text="")

    # spacer(col)

    # row = col.row(align=True)
    # row.prop(prg, "smooth")

    # row = col.row(align=True)
    # row.prop(prg, "cutoff")

    if not limited:
        row = col.row()
        row.prop(prg, "scale")

    row = col.row()
    row.prop(prg, "merge_distance")

    row = col.row()
    row.prop(prg, "lin_deflection")

    row = col.row()
    row.prop(prg, "ang_deflection")

    if not limited:
        # row = col.row()
        # row.prop(prg, "color_choice")

        # row = col.row()
        # row.prop(prg, "norms_choice")

        # row = col.row()
        # row.prop(prg, "rotate_ZY")

        # row = col.row()
        # row.prop(prg, "fw_as")

        row = col.row()
        row.prop(prg, "up_as")


class ImportStepCADOperator(bpy.types.Operator, ImportHelper):
    bl_idname = "import_scene.occ_import_step"
    bl_label = "Import STEP"
    bl_description = "Import a STEP file"

    filter_glob: StringProperty(
        default="*.step;*.stp;*.st",
        options={"HIDDEN"},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )

    prg: bpy.props.PointerProperty(type=PG_Stepper)

    def execute(self, context):
        print("Opening file:", self.filepath)
        if self.prg.interactive:
            wm = context.window_manager
            self._timer = wm.event_timer_add(time_step=0.01, window=context.window)
            wm.modal_handler_add(self)
            self.executor = self.main(context)
            return {"RUNNING_MODAL"}
        else:
            executor = self.main(context)
            for _ in executor:
                pass
            return {"FINISHED"}

    def draw(self, context):
        draw_interface(self, context, self.prg)

    def modal(self, context, event):
        res = next(self.executor)
        if "FINISHED" in res:
            return {"FINISHED"}
        if event.type in {"ESC"}:
            return {"CANCELLED"}
        return {"RUNNING_MODAL"}

    def cancel(self, context):
        # TODO: does this happen every time?
        if hasattr(self, "_timer"):
            context.window_manager.event_timer_remove(self._timer)

    def main(self, context):
        from . import importer

        filename = "".join(ntpath.basename(self.filepath).split(".")[:-1])

        if self.filepath not in global_file_cache:
            shapes_labels_colors, tree = importer.read_step(self.filepath)
            global_file_cache[self.filepath] = (shapes_labels_colors, tree)
        else:
            shapes_labels_colors, tree = global_file_cache[self.filepath]
            print("Loaded file from cache")

        yield {"REDRAW"}
        print("--- BUILDING")

        # create base collection
        master_collection = bpy.data.collections.new(filename + ".flat")
        mcoll_name = master_collection.name
        print(mcoll_name)
        bpy.context.scene.collection.children.link(master_collection)

        wm = bpy.context.window_manager
        total = len(shapes_labels_colors)

        # vcol_name = "Colors"
        created_objs = []
        created_names = {}
        created_collections = {}

        # traverse shapes, render in "face" mode
        wm.progress_begin(0, total)
        for i, shp in enumerate(shapes_labels_colors):
            label, color, tag, parent_uuid = shapes_labels_colors[shp]
            if self.prg.ignore_empty and len(label) == 0:
                continue

            shape_name = label + str(tag)

            wm.progress_update(i)
            yield {"REDRAW"}

            print("Building ({}/{}): {}".format(i, total, label))

            if self.prg.linked_copies and shape_name in created_names:
                # create dupes from name match
                # source_obj = bpy.data.objects.get(label)
                source_obj = created_names[shape_name]
                obj = source_obj.copy()
                created_objs.append(obj)
                mtx = importer.trsf_matrix(shp.Location().Transformation())
                for row in range(mtx.shape[0]):
                    for col in range(mtx.shape[1]):
                        obj.matrix_world[row][col] = mtx[row][col]

                # create/place subcollection
                group_name = label
                # max collection name len = 61
                if len(group_name) > 50:
                    group_name = group_name[:25] + "_" + group_name[-25:]

                # TODO: check dupe collections for dupe imports
                if group_name not in created_collections:
                    group_collection = bpy.data.collections.new(group_name)
                    created_collections[group_name] = group_collection
                    master_collection.children.link(group_collection)
                    # group_collection.objects.link(source_obj)
                    # master_collection.objects.unlink(source_obj)
                    exclusive_collection_link(source_obj, group_collection)
                else:
                    group_collection = created_collections[group_name]

                group_collection.objects.link(obj)

                # how to make parent (don't add obj to created_objs)
                # obj.parent = source_obj
                # obj.matrix_parent_inverse = source_obj.matrix_world.inverted()
                # master_collection.objects.link(obj)
            else:
                bpy.ops.mesh.primitive_cube_add()
                obj = bpy.context.active_object
                obj.name = label
                # obj.data.create_normals_split()

                created_objs.append(obj)
                created_names[shape_name] = obj

                bpy.ops.object.mode_set(mode="OBJECT")

                mtx = build_mesh(
                    obj.data,
                    shp,
                    self.prg.lin_deflection,
                    self.prg.ang_deflection,
                    color,
                    only_bbox=self.prg.only_bbox,
                )

                # copy object transform from CAD to Blender
                for row in range(mtx.shape[0]):
                    for col in range(mtx.shape[1]):
                        obj.matrix_world[row][col] = mtx[row][col]

                # merge by distance
                if self.prg.merge_distance > 0.0:
                    context_free_merge(obj, self.prg.merge_distance)

                exclusive_collection_link(obj, master_collection)

            # gc: label, color, tag

            # assign property to obj
            obj["STEP_tag"] = tag
            obj["STEP_parent"] = parent_uuid
            obj["STEP_file"] = self.filepath

        # build tree
        tree_collection = bpy.data.collections.new(filename + ".hierarchy")
        bpy.context.scene.collection.children.link(tree_collection)
        hierarchy_collections = {}

        def node_parse(node, level, parent_collection):
            if "name" in node and node["children"] is not None:
                print(" " * (level * 2) + node["name"], node["uuid"])
                collection_node = bpy.data.collections.new(node["name"])
                # print(node["uuid"], type(node["uuid"]))
                hierarchy_collections[node["uuid"]] = collection_node
                parent_collection.children.link(collection_node)
                for c in node["children"]:
                    node_parse(c, level + 1, collection_node)

        if tree["children"] is not None:
            for c in tree["children"]:
                node_parse(c, 0, tree_collection)

            # link objects to tree
            if len(hierarchy_collections.items()) > 0:
                for obj in created_objs:
                    # print(obj.name, obj["STEP_parent"])
                    hierarchy_collections[obj["STEP_parent"]].objects.link(obj)

        # transforms and processing of objects
        bpy.ops.object.select_all(action="DESELECT")

        print(filename)

        for obj in created_objs:
            obj.select_set(True)
            obj.data.use_auto_smooth = True
            obj.data.auto_smooth_angle = 3.14159
            if self.prg.only_bbox:
                obj.display_type = "BOUNDS"

        # disable for now
        if False and self.prg.interactive:
            # let the hacks commence
            outliner = [a for a in bpy.context.screen.areas.values() if a.ui_type == "OUTLINER"][0]
            bpy.context.window.cursor_warp(outliner.x + 10, outliner.y + 10)
            outliner.tag_redraw()
            yield {"REDRAW"}
            for k, v in created_collections.items():
                outliner.spaces[0].filter_text = k
                yield {"REDRAW"}
                bpy.ops.outliner.show_one_level({"area": outliner}, "INVOKE_DEFAULT", open=False)
                outliner.tag_redraw()
                yield {"REDRAW"}
            outliner.spaces[0].filter_text = ""

        # up
        up_as = self.prg.up_as
        up_axis = {"X": 0, "Y": 1, "Z": 2}[up_as[0]]

        # forward
        # fw_as = self.prg.fw_as
        # fw_axis = {"X": 0, "Y": 1, "Z": 2}[fw_as[0]]

        def _scalemat(mat, sl):
            scaling = np.zeros_like(mat)
            scaling[np.diag_indices(4)] = sl
            # print(scaling)
            return np.matmul(scaling, mat)

        for obj in created_objs:
            # up, forward
            mat = np.array(obj.matrix_world)

            # blender default: Y(1) = forward, Z(2) = up
            if up_axis != 2:
                # if negate axis, do mirror
                # if up_as[1] == "N":
                #     dg = [1, 1, 1, 1]
                #     dg[up_axis] = -1
                #     mat = _scalemat(mat, dg)

                mat[[up_axis, 2]] = mat[[2, up_axis]]
                mat[up_axis] *= -1

            # scale
            mat = _scalemat(mat, [*([self.prg.scale] * 3), 1])

            # store
            for row in range(4):
                for col in range(4):
                    obj.matrix_world[row][col] = mat[row][col]

        # if up_axis == "Y":
        #     rotate_selection_on_axis(np.pi / 2, "X")
        #     if up_as == "YNEG":
        #         rotate_selection_on_axis(np.pi, "X")

        # if up_axis == "X":
        #     rotate_selection_on_axis(-np.pi / 2, "Y")
        #     if up_as == "XNEG":
        #         rotate_selection_on_axis(np.pi, "Y")

        # if up_axis == "Z":
        #     if up_as == "ZNEG":
        #         rotate_selection_on_axis(np.pi, "Z")

        # average_location = mu.Vector([0.0, 0.0, 0.0])
        # for obj in created_objs:
        #     average_location += obj.location
        # average_location /= len(created_objs)

        # bpy.context.scene.tool_settings.transform_pivot_point = "CURSOR"
        # bpy.context.scene.cursor.location = mu.Vector([0.0, 0.0, 0.0])
        # bpy.ops.view3d.snap_selected_to_cursor(use_offset=True)

        wm.progress_end()

        yield {"FINISHED"}


class STEP_OT_ClearCache(bpy.types.Operator):
    bl_idname = "object.occ_clear_cache"
    bl_label = "Clear STEP cache"
    bl_description = "Clear STEP cache, enabling the reload of a file"

    def execute(self, context):
        # utils.memorytrace_print()
        # global global_file_cache
        # items = list(global_file_cache.values())
        # for entry in items:
        #     for i, shp in enumerate(entry):
        #         label, color, tag = entry[shp]
        #         # shp.Nullify()

        global_file_cache.clear()
        return {"FINISHED"}


class STEP_OT_RebuildSelected(bpy.types.Operator):
    bl_idname = "object.occ_rebuild_selected"
    bl_label = "Rebuild selected objects from the STEP file"
    bl_description = "Experimental: Causes issues on some shapes\n" + bl_label

    def execute(self, context):
        meshes = {}
        prevname = ""
        curname = ""
        shapes_labels_colors = None
        build_tags = set()
        rebuilt_meshes = set()
        my_selection = list(context.selected_objects)

        ang_def = context.scene.stepper.ang_deflection
        lin_def = context.scene.stepper.lin_deflection
        merge_distance = context.scene.stepper.merge_distance

        # select all objs with the same meshes
        for obj in my_selection:
            for other_obj in context.scene.objects:
                if obj.data == other_obj.data:
                    other_obj.select_set(True)

        # go through all selected and rebuild the meshes
        wm = bpy.context.window_manager
        wm.progress_begin(0, len(my_selection))
        for progress_count, obj in enumerate(my_selection):
            if obj.data.name not in meshes:
                meshes[obj.data.name] = obj.data
                sel_tag = obj["STEP_tag"]
                prevname = curname
                curname = obj["STEP_file"]
            else:
                assert meshes[obj.data.name] == obj.data

            if sel_tag in rebuilt_meshes:
                continue

            if prevname != curname:
                if curname in global_file_cache:
                    shapes_labels_colors, _ = global_file_cache[curname]
                else:
                    shapes_labels_colors = None

            if shapes_labels_colors == None:
                self.report(
                    {"ERROR"},
                    'STEP loader: Object "{}" not found in cache for file {}'.format(
                        obj.name, curname
                    ),
                )
                break

            for i, shp in enumerate(shapes_labels_colors):
                label, color, tag, parent_uuid = shapes_labels_colors[shp]
                if tag == sel_tag and len(label) > 0:
                    rebuilt_meshes.add(sel_tag)
                    print("Rebuilding:", sel_tag, obj.data.name, label)
                    build_mesh(
                        obj.data, shp, lin_def, ang_def, color, only_bbox=False, verbose=False
                    )
                    # print("--built mesh")
                    obj.display_type = "TEXTURED"
                    context_free_merge(obj, merge_distance)
                    build_tags.add(obj["STEP_tag"])
                    break

            wm.progress_update(progress_count)

        wm.progress_end()

        for obj in context.selected_objects:
            obj.display_type = "TEXTURED"

        return {"FINISHED"}


class STEP_PT_STEPper(bpy.types.Panel):
    bl_label = "STEPper"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Import"

    def draw(self, context):
        prg = context.scene.stepper
        draw_interface(self, context, prg, limited=True)

        layout = self.layout
        # layout.label(text="Used memory: {}".format(total_size(global_file_cache)))
        row = layout.row()
        row.operator(STEP_OT_RebuildSelected.bl_idname, text="Rebuild selected")


def menu_func_import(self, context):
    self.layout.operator(ImportStepCADOperator.bl_idname, text="STEP (.step)")


classes = (
    PG_Stepper,
    ImportStepCADOperator,
    STEP_OT_ClearCache,
    STEP_OT_RebuildSelected,
    STEP_PT_STEPper,
)
# classes = (ImportStepCADOperator, )


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.stepper = bpy.props.PointerProperty(type=PG_Stepper)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)


def unregister():
    for c in classes[::-1]:
        bpy.utils.unregister_class(c)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    del bpy.types.Scene.stepper
