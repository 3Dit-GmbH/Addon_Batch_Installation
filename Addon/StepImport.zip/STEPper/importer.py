import sys
from os.path import dirname

import numpy as np

sys.path.append(dirname(__file__))

import os

from OCC.Core.BRepMesh import BRepMesh_IncrementalMesh
from OCC.Core.IFSelect import IFSelect_RetDone
from OCC.Core.TDocStd import TDocStd_Document
from OCC.Core.XCAFDoc import XCAFDoc_DocumentTool_ShapeTool, XCAFDoc_DocumentTool_ColorTool
from OCC.Core.STEPCAFControl import STEPCAFControl_Reader
from OCC.Core.TDF import TDF_LabelSequence, TDF_Label
from OCC.Core.TCollection import TCollection_ExtendedString
from OCC.Core.Quantity import Quantity_Color, Quantity_TOC_RGB
from OCC.Core.TopLoc import TopLoc_Location
from OCC.Core.BRepBuilderAPI import BRepBuilderAPI_Transform
from OCC.Core.BRep import BRep_Tool
from OCC.Core.BRepTools import breptools
from OCC.Core.TopExp import TopExp_Explorer
from OCC.Core.TopoDS import topods_Face
from OCC.Core.TopAbs import TopAbs_FACE, TopAbs_FORWARD, TopAbs_REVERSED
from OCC.Core.Bnd import Bnd_Box
from OCC.Core.BRepBndLib import brepbndlib_Add
from OCC.Core.BRepLProp import BRepLProp_SLProps
from OCC.Core.BRepAdaptor import BRepAdaptor_Surface
from OCC.Core.Poly import poly

# from OCC.Core.gp import gp_Vec, gp_Pnt2d, gp_Pnt, gp_Dir, gp_Pln, gp_Trsf, gp_XYZ

from . import OCC

print("[STEP import] OCC version:", OCC.VERSION)


def read_step_file_with_names_colors(filename):
    """ Returns list of tuples (topods_shape, label, color)
    Use OCAF.
    """
    if not os.path.isfile(filename):
        raise FileNotFoundError("%s not found." % filename)
    # the list:
    output_shapes = {}

    # create an handle to a document
    doc = TDocStd_Document(TCollection_ExtendedString("pythonocc-doc"))

    # Get root assembly
    shape_tool = XCAFDoc_DocumentTool_ShapeTool(doc.Main())
    color_tool = XCAFDoc_DocumentTool_ColorTool(doc.Main())
    # layer_tool = XCAFDoc_DocumentTool_LayerTool(doc.Main())
    # mat_tool = XCAFDoc_DocumentTool_MaterialTool(doc.Main())

    step_reader = STEPCAFControl_Reader()
    step_reader.SetColorMode(True)
    step_reader.SetLayerMode(True)
    step_reader.SetNameMode(True)
    step_reader.SetMatMode(True)
    step_reader.SetGDTMode(True)

    print("DataExchange: Reading STEP")
    status = step_reader.ReadFile(filename)
    print("DataExchange: Transferring")
    if status == IFSelect_RetDone:
        step_reader.Transfer(doc)

    locs = []
    print("DataExchange: Transfer done")

    def _get_sub_shapes(lab, loc, level, count, tree):
        # print(" " * (2 * level) + lab.GetLabelName(), parent, end="")
        count["value"] += 1
        # print("DataExchange reading sub shape:", lab.DumpToString())
        # print("assembly:{} free:{} shape:{} compound:{} component:{} simple:{}".format(
        #     shape_tool.IsAssembly(lab),
        #     shape_tool.IsFree(lab),
        #     shape_tool.IsShape(lab),
        #     shape_tool.IsCompound(lab),
        #     shape_tool.IsComponent(lab),
        #     shape_tool.IsSimpleShape(lab)
        # ))

        # users = TDF_LabelSequence()
        # users_cnt = shape_tool.GetUsers(lab, users)
        # print("Nr Users       :", users_cnt)

        l_subss = TDF_LabelSequence()
        shape_tool.GetSubShapes(lab, l_subss)
        # print(" subs:", l_subss.Length(), end="")
        l_comps = TDF_LabelSequence()
        shape_tool.GetComponents(lab, l_comps)
        # print(" comps:", l_comps.Length())

        if shape_tool.IsAssembly(lab):
            l_c = TDF_LabelSequence()
            shape_tool.GetComponents(lab, l_c)
            tree["children"] = []
            for i in range(l_c.Length()):
                label = l_c.Value(i + 1)
                if shape_tool.IsReference(label):
                    label_reference = TDF_Label()
                    shape_tool.GetReferredShape(label, label_reference)
                    loc = shape_tool.GetLocation(label)
                    locs.append(loc)
                    node = {
                        "parent": tree["uuid"],
                        "uuid": count["value"],
                        "tag": label_reference.Tag(),
                        "name": label_reference.GetLabelName(),
                        "children": None,
                    }
                    _get_sub_shapes(label_reference, loc, level + 1, count, node)
                    tree["children"].append(node)
                    locs.pop()

        elif shape_tool.IsSimpleShape(lab):
            shape = shape_tool.GetShape(lab)
            loc = TopLoc_Location()
            for l in locs:
                loc = loc.Multiplied(l)

            c = Quantity_Color(0.5, 0.5, 0.5, Quantity_TOC_RGB)  # default color
            colorSet = False
            if (
                color_tool.GetInstanceColor(shape, 0, c)
                or color_tool.GetInstanceColor(shape, 1, c)
                or color_tool.GetInstanceColor(shape, 2, c)
            ):
                color_tool.SetInstanceColor(shape, 0, c)
                color_tool.SetInstanceColor(shape, 1, c)
                color_tool.SetInstanceColor(shape, 2, c)
                colorSet = True

            if not colorSet:
                if (
                    color_tool.GetColor(lab, 0, c)
                    or color_tool.GetColor(lab, 1, c)
                    or color_tool.GetColor(lab, 2, c)
                ):
                    color_tool.SetInstanceColor(shape, 0, c)
                    color_tool.SetInstanceColor(shape, 1, c)
                    color_tool.SetInstanceColor(shape, 2, c)

            shape_disp = BRepBuilderAPI_Transform(shape, loc.Transformation()).Shape()
            if shape_disp not in output_shapes:
                output_shapes[shape_disp] = [lab.GetLabelName(), c, lab.Tag(), tree["parent"]]
            for i in range(l_subss.Length()):
                lab_subs = l_subss.Value(i + 1)
                shape_sub = shape_tool.GetShape(lab_subs)

                c = Quantity_Color(0.5, 0.5, 0.5, Quantity_TOC_RGB)  # default color
                colorSet = False
                if (
                    color_tool.GetInstanceColor(shape_sub, 0, c)
                    or color_tool.GetInstanceColor(shape_sub, 1, c)
                    or color_tool.GetInstanceColor(shape_sub, 2, c)
                ):
                    color_tool.SetInstanceColor(shape_sub, 0, c)
                    color_tool.SetInstanceColor(shape_sub, 1, c)
                    color_tool.SetInstanceColor(shape_sub, 2, c)
                    colorSet = True

                if not colorSet:
                    if (
                        color_tool.GetColor(lab_subs, 0, c)
                        or color_tool.GetColor(lab_subs, 1, c)
                        or color_tool.GetColor(lab_subs, 2, c)
                    ):
                        color_tool.SetInstanceColor(shape, 0, c)
                        color_tool.SetInstanceColor(shape, 1, c)
                        color_tool.SetInstanceColor(shape, 2, c)

                shape_to_disp = BRepBuilderAPI_Transform(shape_sub, loc.Transformation()).Shape()
                # position the subshape to display
                if shape_to_disp not in output_shapes:
                    output_shapes[shape_to_disp] = [
                        lab_subs.GetLabelName(),
                        c,
                        lab_subs.Tag(),
                        tree["parent"],
                    ]
        else:
            print("DataExchange error: Item is neither assembly or a simple shape")

    def _get_shapes():
        print("DataExchange: Init get_shapes()")
        labels = TDF_LabelSequence()
        shape_tool.GetFreeShapes(labels)
        print("\nNumber of shapes at root:", labels.Length())
        count = {"value": 0}
        tree = {"parent": None, "uuid": -1, "name": "", "children": []}
        for i in range(labels.Length()):
            root_item = labels.Value(i + 1)
            print("DataExchange: Reading shape ({}/{})".format(i, labels.Length()))
            node = {
                "parent": -1,
                "uuid": count["value"],
                "tag": root_item.Tag(),
                "name": root_item.GetLabelName(),
                "children": None,
            }
            _get_sub_shapes(root_item, None, 0, count, node)
            tree["children"].append(node)

        return tree

    tree = _get_shapes()

    # import json
    # print(json.dumps(tree, indent=2))

    return output_shapes, tree


def b_XYZ(v):
    x = v.XYZ()
    return (x.X(), x.Y(), x.Z())


def tri_coords(tri, tab):
    idxs = tri.Get()
    coords = [tab.Value(i) for i in idxs]
    return [b_XYZ(t) for t in coords]


def trsf_matrix(trsf):
    matrix = np.empty((3, 4), dtype=np.float32)
    for row in range(1, 4):
        for col in range(1, 5):
            matrix[row - 1, col - 1] = trsf.Value(row, col)
    return matrix


def read_step(filename):
    return read_step_file_with_names_colors(filename)


def build_bm(shape, bm, style="TRIANGLES", lin_def=0.8, ang_def=0.5):
    # Apply transformation to objects
    # print("------transforms")
    # print(type(shape))
    # print(type(shape.Location()))
    tform = shape.Location().Transformation()
    # print(type(tform))
    # print("------matrix")
    matrix = trsf_matrix(tform)
    # matrix = np.empty((3, 4), dtype=np.float32)
    # for row in range(1, 4):
    #     for col in range(1, 5):
    #         matrix[row - 1, col - 1] = tform.Value(row, col)

    # shape.Location(shape.Location().Inverted())
    # sloc = tform.TranslationPart()
    # dislocate = mu.Vector(b_XYZ(sloc))
    # sscale = tform.ScaleFactor()

    norms = []

    if style == "BOUNDING_BOX":
        # reset OCC transform, calculate BB, redo OCC transform
        temp = tform.Inverted()
        move_around = not np.array_equal(trsf_matrix(temp), trsf_matrix(tform))
        if move_around:
            brep_trns = BRepBuilderAPI_Transform(temp)
            brep_trns.Perform(shape)
            shape = brep_trns.Shape()

        bbox = Bnd_Box()
        bbox.SetGap(1e-6)
        brepbndlib_Add(shape, bbox, False)
        xmin, ymin, zmin, xmax, ymax, zmax = bbox.Get()
        bm.verts.new([xmin, ymin, zmin])
        bm.verts.new([xmax, ymax, zmax])

        if move_around:
            brep_trns = BRepBuilderAPI_Transform(tform)
            brep_trns.Perform(shape)
            shape = brep_trns.Shape()

    if style == "TRIANGLES":
        # print("------BRepMesh_Increment")
        # stype = shape.ShapeType()

        # Only triangulate those which can
        # if stype != TopAbs_FACE and stype != TopAbs_SOLID and stype != TopAbs_SHELL:
        #     print("Skipped shape:", shape)
        #     print("null:", shape.IsNull())
        #     print("type:", shape.ShapeType())
        #     print("closed:", shape.Closed())
        #     print("infinite:", shape.Infinite())
        #     print("convex:", shape.Convex())
        #     print("orientable:", shape.Orientable())
        #     print("checked:", shape.Checked())
        #     print("locked:", shape.Locked())
        #     print("free:", shape.Free())
        #     return matrix, None

        bt = BRep_Tool()
        brept = breptools()
        brept.Clean(shape)

        ex = TopExp_Explorer(shape, TopAbs_FACE)
        ex_More = ex.More()
        if not ex_More:
            print("Empty compound, skip shape.")
            return matrix, None

        mesh = BRepMesh_IncrementalMesh(shape, lin_def, False, ang_def, True)
        # mesh = BRepMesh_IncrementalMesh(shape, lin_def)
        # mesh.SetParallelDefault(True)
        # print("------Explorer")
        ex = TopExp_Explorer(shape, TopAbs_FACE)
        while ex.More():
            # count += 1
            # if count > 3:
            #     break
            face = topods_Face(ex.Current())
            location = TopLoc_Location()
            facing = bt.Triangulation(face, location)
            if facing is None:
                # error
                print("Mesh error! No triangulation found for part.")
                ex.Next()
                continue

            # print(face.Orientation(), end=" / ")

            # rot_xyz = gp_XYZ()
            # rot_angle = 0.0
            # location.Transformation().GetRotation(rot_xyz, rot_angle)

            # qt_rot = location.Transformation().GetRotation()
            # print(qt_rot.X(), qt_rot.Y(), qt_rot.Z(), qt_rot.W())

            normcalc = poly()
            normcalc.ComputeNormals(facing)

            surface = BRepAdaptor_Surface(face)
            # aSurf = bt.Surface(face)

            # uFirst = surface.FirstUParameter()
            # uLast = surface.LastUParameter()
            # vFirst = surface.FirstVParameter()
            # vLast = surface.LastVParameter()
            # uMid = (uFirst + uLast) / 2.0
            # vMid = (vFirst + vLast) / 2.0

            # prop = BRepLProp_SLProps(surface, uMid, vMid, 2, 1e-4)
            prop = BRepLProp_SLProps(surface, 2, 1e-4)

            tab = facing.Nodes()
            face_uv = facing.UVNodes()
            verts = []
            tnorms = []
            undef_normals = False
            for t in range(1, facing.NbNodes() + 1):
                # gen_norm = facing.Normal(t)

                loc = b_XYZ(tab.Value(t))
                nvert = bm.verts.new(loc)
                nvert.index = t - 1
                verts.append(nvert)

                uv = face_uv.Value(t)
                u, v = uv.X(), uv.Y()
                # prop.SetParameters(u * 0.5 + 0.5, v * 0.5 + 0.5)
                # prop.SetParameters(0.5, 0.5)
                prop.SetParameters(u, v)
                if prop.IsNormalDefined():
                    # pnt = gp_Pnt()
                    # vec = gp_Vec()
                    # BRepGProp_Face(face).Normal(u, v, pnt, vec)
                    # vec = vec.Transformed(location.Transformation())
                    # nn = np.array(b_XYZ(vec))

                    # est_norm = gp_Dir()
                    # p2d = gp_Pnt2d(u, v)
                    # if geomlib.NormEstim(aSurf, p2d, 0.1, est_norm) <= 1:
                    #     nn = np.array(b_XYZ(est_norm))

                    # oc_norm = gen_norm
                    oc_norm = prop.Normal().Transformed(tform.Inverted())
                    nn = np.array(b_XYZ(oc_norm))

                    # nn = np.array([1.0, 0.0, 0.0])

                    # if face.Orientation() != TopAbs_FORWARD:
                    if face.Orientation() == TopAbs_REVERSED:
                        nn = -nn

                    tnorms.append(nn)

                # nn = np.array(b_XYZ(gen_norm))

                else:
                    nn = np.zeros((3,))
                    tnorms.append(nn)
                    undef_normals = True

            if undef_normals:
                print("Problem: undefined normals found")

            # print(b_XYZ(location.Transformation().GetRotation().XYZ()))
            # print(location.IsIdentity())

            tri = facing.Triangles()
            # nrm = facing.Normals()
            for i in range(facing.NbTriangles()):
                idxs = tri.Value(i + 1).Get()
                assert len(idxs) == 3
                new_verts = [verts[ix - 1] for ix in idxs]
                new_norms = [tnorms[ix - 1] for ix in idxs]

                if face.Orientation() != TopAbs_FORWARD:
                    new_verts[1], new_verts[0] = new_verts[0], new_verts[1]
                    new_norms[1], new_norms[0] = new_norms[0], new_norms[1]

                nf = bm.faces.new(new_verts)
                nf.smooth = True
                # nf.normal_update()

                for li, l in enumerate(nf.loops):
                    # match vert & norm
                    assert l.vert == new_verts[li]
                    norms.append(new_norms[li])

                # t0 = nf.normal
                # t1 = norms[-1].copy()
                # t1 += norms[-2]
                # t1 += norms[-3]
                # t1 = t1 / np.linalg.norm(t1)
                # if t0.dot(t1) < 0.5:
                #     nf.normal_flip()

                # nrm.Value(i + 1) < 0:

            ex.Next()

    return matrix, norms
